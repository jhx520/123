const s="/assets/password.bd1617ac.svg";export{s as default};
