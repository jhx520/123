const s="/assets/pdf.77bd44ca.svg";export{s as default};
