const o="/assets/monitor.bc6d6338.svg";export{o as default};
