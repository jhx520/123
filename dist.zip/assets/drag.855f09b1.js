const s="/assets/drag.f4e33e85.svg";export{s as default};
