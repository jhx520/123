const e="/assets/excel.b8970c32.svg";export{e as default};
