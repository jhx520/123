const e="/assets/example.20668f6a.svg";export{e as default};
