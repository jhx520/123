const e="/assets/number.674e5424.svg";export{e as default};
