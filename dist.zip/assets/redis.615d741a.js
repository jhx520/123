const s="/assets/redis.219b773c.svg";export{s as default};
