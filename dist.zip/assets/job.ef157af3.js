const a="/assets/job.0a38faae.svg";export{a as default};
