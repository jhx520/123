const s="/assets/icon.26344985.svg";export{s as default};
