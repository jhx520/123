const c="/assets/checkbox.c4f0703b.svg";export{c as default};
