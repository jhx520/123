const a="/assets/table.8c21c0da.svg";export{a as default};
