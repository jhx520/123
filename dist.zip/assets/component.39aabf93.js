const e="/assets/component.8f346aae.svg";export{e as default};
