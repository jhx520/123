const s="/assets/form.c28e12cd.svg";export{s as default};
