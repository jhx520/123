const s="/assets/404.ddd506c6.svg";export{s as default};
