const s="/assets/lock.eb3ac9a3.svg";export{s as default};
