const o="/assets/tool.f015d958.svg";export{o as default};
