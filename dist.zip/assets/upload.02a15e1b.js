const a="/assets/upload.ad3bb44a.svg";export{a as default};
