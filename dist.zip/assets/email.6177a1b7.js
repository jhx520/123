const e="/assets/email.29d2e375.svg";export{e as default};
