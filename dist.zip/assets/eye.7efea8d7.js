const e="/assets/eye.0577dd93.svg";export{e as default};
