const s="/assets/dict.e03b117d.svg";export{s as default};
