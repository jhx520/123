const s="/assets/size.fb05acae.svg";export{s as default};
