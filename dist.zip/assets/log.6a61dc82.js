const s="/assets/log.1cbe92a9.svg";export{s as default};
