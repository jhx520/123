const s="/assets/system.99991b71.svg";export{s as default};
