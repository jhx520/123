const s="/assets/qq.9e3df35a.svg";export{s as default};
