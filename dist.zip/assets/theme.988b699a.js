const e="/assets/theme.47bd8f77.svg";export{e as default};
