const a="/assets/date.47a735ed.svg";export{a as default};
