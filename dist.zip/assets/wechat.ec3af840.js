const a="/assets/wechat.9e78a6a9.svg";export{a as default};
