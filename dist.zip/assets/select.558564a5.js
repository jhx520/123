const s="/assets/select.2173c004.svg";export{s as default};
