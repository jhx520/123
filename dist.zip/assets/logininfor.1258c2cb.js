const o="/assets/logininfor.9f779b90.svg";export{o as default};
