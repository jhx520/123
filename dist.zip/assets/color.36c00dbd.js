const a="/assets/color.a2a1a4c2.svg";export{a as default};
