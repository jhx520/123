const s="/assets/education.4308b70c.svg";export{s as default};
