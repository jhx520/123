const e="/assets/code.4fee30a6.svg";export{e as default};
