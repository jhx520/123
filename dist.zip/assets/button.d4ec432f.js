const t="/assets/button.04c839d6.svg";export{t as default};
