const e="/assets/people.be8c31f9.svg";export{e as default};
