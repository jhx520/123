const s="/assets/shopping.4f0d6668.svg";export{s as default};
