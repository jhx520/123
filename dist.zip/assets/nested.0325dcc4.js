const s="/assets/nested.d8786b25.svg";export{s as default};
