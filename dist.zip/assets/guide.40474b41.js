const e="/assets/guide.441e177e.svg";export{e as default};
