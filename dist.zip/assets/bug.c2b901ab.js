const s="/assets/bug.6072aa1f.svg";export{s as default};
