const s="/assets/question.0a0bd91d.svg";export{s as default};
