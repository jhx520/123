const e="/assets/time.b96368e0.svg";export{e as default};
