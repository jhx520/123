const e="/assets/peoples.8b86ef22.svg";export{e as default};
