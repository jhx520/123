const s="/assets/tab.d7c08170.svg";export{s as default};
