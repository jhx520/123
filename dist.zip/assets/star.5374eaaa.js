const s="/assets/star.dc81e60f.svg";export{s as default};
