const e="/assets/tree-table.57eb7565.svg";export{e as default};
