const e="/assets/exit-fullscreen.edd6f137.svg";export{e as default};
