const s="/assets/post.19463d24.svg";export{s as default};
