const s="/assets/cascader.86d686bd.svg";export{s as default};
