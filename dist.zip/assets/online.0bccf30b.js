const e="/assets/online.5f3e51bc.svg";export{e as default};
