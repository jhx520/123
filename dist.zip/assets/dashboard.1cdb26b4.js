const a="/assets/dashboard.742fa6e8.svg";export{a as default};
