const s="/assets/link.b0c4e028.svg";export{s as default};
