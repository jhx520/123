const a="/assets/chart.a027cd52.svg";export{a as default};
