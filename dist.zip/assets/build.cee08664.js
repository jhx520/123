const s="/assets/build.df478a2b.svg";export{s as default};
