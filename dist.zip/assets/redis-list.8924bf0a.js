const s="/assets/redis-list.df08ee8d.svg";export{s as default};
