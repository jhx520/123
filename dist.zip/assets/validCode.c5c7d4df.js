const a="/assets/validCode.78b8cac8.svg";export{a as default};
