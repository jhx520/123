const s="/assets/row.55339924.svg";export{s as default};
