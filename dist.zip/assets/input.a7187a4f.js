const s="/assets/input.dc49aded.svg";export{s as default};
