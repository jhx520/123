const t="/assets/documentation.92323cc6.svg";export{t as default};
