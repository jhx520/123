const e="/assets/tree.60cea6a4.svg";export{e as default};
