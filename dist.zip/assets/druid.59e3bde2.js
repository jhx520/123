const s="/assets/druid.57ab4984.svg";export{s as default};
