const s="/assets/list.1107b3b6.svg";export{s as default};
