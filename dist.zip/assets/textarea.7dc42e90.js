const a="/assets/textarea.a253c0f4.svg";export{a as default};
