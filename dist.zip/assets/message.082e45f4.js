const s="/assets/message.cb1eb2d5.svg";export{s as default};
