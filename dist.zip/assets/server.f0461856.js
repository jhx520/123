const e="/assets/server.6de32aac.svg";export{e as default};
