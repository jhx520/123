const s="/assets/slider.f34180f2.svg";export{s as default};
