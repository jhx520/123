const a="/assets/date-range.be0a664d.svg";export{a as default};
