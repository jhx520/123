const e="/assets/time-range.18c6ed64.svg";export{e as default};
