const s="/assets/github.559c5791.svg";export{s as default};
