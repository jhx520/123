const s="/assets/phone.a711d14f.svg";export{s as default};
