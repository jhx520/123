const s="/assets/user.64e211ff.svg";export{s as default};
