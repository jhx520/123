const e="/assets/fullscreen.fdad759e.svg";export{e as default};
