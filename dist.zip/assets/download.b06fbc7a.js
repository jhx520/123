const a="/assets/download.98fa3b20.svg";export{a as default};
