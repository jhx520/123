const t="/assets/international.cdcfd9eb.svg";export{t as default};
