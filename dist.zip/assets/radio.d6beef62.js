const s="/assets/radio.30b8b47c.svg";export{s as default};
