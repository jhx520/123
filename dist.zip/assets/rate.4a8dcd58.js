const s="/assets/rate.2822f76c.svg";export{s as default};
