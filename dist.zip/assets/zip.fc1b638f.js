const s="/assets/zip.f12aeb4c.svg";export{s as default};
