const s="/assets/switch.ffcc91cd.svg";export{s as default};
