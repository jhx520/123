const s="/assets/edit.88acfa6c.svg";export{s as default};
