const a="/assets/clipboard.9c56eaf6.svg";export{a as default};
