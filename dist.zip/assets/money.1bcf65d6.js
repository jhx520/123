const s="/assets/money.ba9bc644.svg";export{s as default};
