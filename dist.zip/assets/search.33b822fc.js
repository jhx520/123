const s="/assets/search.b05d8499.svg";export{s as default};
