const s="/assets/swagger.c07d48c2.svg";export{s as default};
