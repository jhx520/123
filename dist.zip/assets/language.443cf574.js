const a="/assets/language.407b7548.svg";export{a as default};
