const s="/assets/skill.025afb8f.svg";export{s as default};
